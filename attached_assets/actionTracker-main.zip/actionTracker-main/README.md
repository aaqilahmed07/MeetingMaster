YouTube preview: https://youtu.be/OCPY7hL618I
Index page: https://marinazub.github.io/actionTracker/docs/index.html
